export const environment = {
    production: true,
    baseUrl: 'https://notes-api.zhenyangnodejs.fr/api',
    videoPlayerService: 'https://front-services.yangzhen.fr',
    s3Url: 'https://photosofzhenblog.s3.eu-west-3.amazonaws.com',
    s3Root: 'mk'
  };